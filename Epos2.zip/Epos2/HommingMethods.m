classdef HommingMethods
    enumeration
        NotImplemented
        ActualPosition
        HomeSwitchNegSpeed
        HomeSwitchNegSpeedIndex
        HomeSwitchPosSpeed
        HomeSwitchPosSpeedIndex
        CurrentNegSpeed
        CurrentNegSpeedIndex
        CurrentPosSpeed
        CurrentPosSpeedIndex
    end
end
