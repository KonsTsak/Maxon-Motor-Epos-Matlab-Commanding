% tes of epos
a = OpenCommunication;

% Check Error
if ( GetErrorState(a, 1) )
    ClearErrorState(a, 1);
end

% Enable Motor
EnableNode(a, 1);

% Change to Home Mode
SetOperationMode(a, 1, 1);

% Home to actual position
FindHome(a, 1, 1);

% Change to Profile Position
SetOperationMode(a, 1, 6);

% Move to 132000 pulses, with 3000 rpm in velocity and 4000 rpm/s in acc
SetProfilePositionData(a, 1, 3000, 4000 );
MoveToPosition(a, 1, -132000, 1);

% Wait a maximum of 10 seconds until motion done
WaitForTargetReached( a, 1, 10000 );

% Display actual position
msg = sprintf('Actual Motor Position is: %i', GetPosition(a, 1) );
disp( msg );

% Ok
disp('All done ... bye');

% Exit
DisableNode(a, 1);
CloseCommunication(a);
